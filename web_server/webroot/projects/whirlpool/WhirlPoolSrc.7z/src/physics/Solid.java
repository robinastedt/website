/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package physics;

/**
 *
 * @author Robin
 */
public interface Solid {
    public double X = 0.0, Y = 0.0, r = 0.0;
}
