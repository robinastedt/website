package whirlpool;

//
// @author Robin Åstedt
//
public class Config {
    public final double FRICTION = 0.01;
    public final double GRAVITY = 0.0025;
    public final boolean DRAW_MEMBRANE_COMPONENTS = false;
}
