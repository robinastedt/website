package whirlpool.render;

//

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComponent;

// @author Robin Åstedt
//
public class DrawingComponent extends JComponent {
    
    private List<Drawable> drawList;
    
    public DrawingComponent() {
        drawList = new ArrayList<>();
        this.setPreferredSize(new Dimension(800, 600));
    }
    
    public void addObject(Drawable object) {
        drawList.add(object);
    }
    
    public void removeObject(Drawable object) {
        drawList.remove(object);
    }
    
    @Override
    public void paintComponent(Graphics graphics) {
        Graphics2D g = (Graphics2D)graphics;
        g.setColor(Color.black);
        g.fillRect(0, 0, getWidth(), getHeight());
        for (Drawable object : drawList) {
            object.draw(g);
        }
    }
}
