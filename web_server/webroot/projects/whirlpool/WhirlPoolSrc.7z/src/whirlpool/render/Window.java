package whirlpool.render;

//

import java.awt.Graphics;
import java.util.List;
import javax.swing.JFrame;

// @author Robin Åstedt
//
public class Window extends JFrame {
    
    private DrawingComponent dc;
    
    
    public Window() {
        dc = new DrawingComponent();
        add(dc);
        pack();
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
    }
    
    public void addObject(Drawable object) {
        dc.addObject(object);
    }
    
    public void removeObject(Drawable object) {
        dc.removeObject(object);
    }
    
    
}
