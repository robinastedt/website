package whirlpool.cell;

//

import java.awt.Color;
import java.awt.Graphics2D;
import whirlpool.Config;
import whirlpool.render.Drawable;

// @author Robin Åstedt
//
public class Cell implements Drawable {
    private Config config;
    public Membrane[] membranes;
    private double x, y, xv, yv;
    public double X, Y;
    
    private final Object drawLock = new Object();
    
    public Cell(Config config, double x, double y) {
        this.config = config;
        this.x = x;
        this.y = y;
        xv = 0.0;
        yv = 0.0;
        X = x;
        Y = y;
        int membraneCount = 32;
        membranes = new Membrane[membraneCount];
        for (int i = 0; i < membraneCount; i++) {
            double dir = 2 * Math.PI * i / membraneCount;
            membranes[i] = new Membrane(config, this, i, x + 32 * Math.cos(dir), y + 32 * Math.sin(dir));
        }
        
        for (int i = 0; i < membraneCount; i++) {
            membranes[i].init();
        }
    }
    
    public Membrane getLeftNeighbor(int id) {
        return membranes[(membranes.length + id - 1) % membranes.length];
    }
    public Membrane getRightNeighbor(int id) {
        return membranes[(id + 1) % membranes.length];
    }
    
    public void updateInternal(Cell[] otherCells) {
        
        double mass = 10;
        double memTotX = 0.0;
        double memTotY = 0.0;
        
        for (Membrane m : membranes) {
            memTotX += m.X;
            memTotY += m.Y;
            m.updateInternal(otherCells);
        }
        
        double mx = memTotX / membranes.length;
        double my = memTotY / membranes.length;
        
        double fx = mx - X;
        double fy = my - Y + mass * config.GRAVITY;
        

        xv += fx / mass - xv * config.FRICTION;
        yv += fy / mass - yv * config.FRICTION;
        
        
        x += xv;
        y += yv;
        
    }
    
    public void updateExternal() {
        for (Membrane m : membranes) {
            m.updateExternal();
        }
        synchronized (drawLock) {
            X = x;
            Y = y;
        }
    }
    
    public void draw(Graphics2D g) {
        if (config.DRAW_MEMBRANE_COMPONENTS) {
            for (Membrane m : membranes) {
                m.draw(g);
            }
        }
        else {
            int[] memXs = new int[membranes.length];
            int[] memYs = new int[membranes.length];

            for (int i = 0; i < membranes.length; i++) {
                Membrane m = membranes[i];
                synchronized (m.drawLock) {
                    memXs[i] = (int)m.X;
                    memYs[i] = (int)m.Y;
                }
            }
            g.setColor(Color.white);
            g.drawPolygon(memXs, memYs, membranes.length);
        }
        
        /*
        int drawX;
        int drawY;
        synchronized (drawLock) {
            drawX = (int)X;
            drawY = (int)Y;
        }
        g.setColor(Color.white);
        g.drawOval(drawX - 3, drawY - 3, 6, 6);
        */
    }
}
