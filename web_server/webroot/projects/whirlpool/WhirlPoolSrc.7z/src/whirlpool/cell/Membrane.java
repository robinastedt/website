package whirlpool.cell;

//

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;
import whirlpool.Config;
import whirlpool.render.Drawable;

// @author Robin Åstedt
//
public class Membrane implements Drawable {
    private Config config;
    private Cell cell;
    private Membrane m1, m2;
    private final int id;
    private double x, y, xv, yv, r;
    public double X, Y, R;
    
    
    
    public final Object drawLock = new Object();
    
    public Membrane(Config config, Cell cell, int id, double x, double y) {
        this.config = config;
        this.cell = cell;
        this.id = id;
        this.x = x;
        this.y = y;
        xv = 0.0;
        yv = 0.0;
        X = x;
        Y = y;
    }
    
    public void init() {
        m1 = cell.getLeftNeighbor(id);
        m2 = cell.getRightNeighbor(id);
    }
    
    public void updateInternal(Cell[] otherCells) {
        double mass = 100;
        
        double fx = 0.0;
        double fy = 0.0;
        
        for (Cell cell : otherCells) {
            for (Membrane m : cell.membranes) {
                if (m != this) {
                    double dx = m.X - X;
                    double dy = m.Y - Y;
                    double d = Math.sqrt(dx * dx + dy * dy);
                    double threshold = R * 2;
                    if (d < threshold) {
                        double mag = 32.0 * (1.0 - (d / threshold));
                        double magd = mag / d;
                        fx -= dx * magd;
                        fy -= dy * magd;
                    }
                }
            }
        }
        
        double m1dx = m1.X - X;
        double m1dy = m1.Y - Y;
        double m2dx = m2.X - X;
        double m2dy = m2.Y - Y;

        double cdx  = cell.X - X;
        double cdy  = cell.Y - Y;
        double m1d = Math.sqrt(m1dx * m1dx + m1dy * m1dy);
        double m2d = Math.sqrt(m2dx * m2dx + m2dy * m2dy);
        double cd = Math.sqrt(cdx * cdx + cdy * cdy);
        
        double m1fx = m1dx;
        double m1fy = m1dy;
        double m2fx = m2dx;
        double m2fy = m2dy;
        //double cfx = cdx / cd / cd * 128;
        //double cfy = cdy / cd / cd * 128;
        double cfx = cdx / cd / cd * 128 / cd * 64;
        double cfy = cdy / cd / cd * 128 / cd * 64;
        
        r = (m1d + m2d) / 4.0;
        
        fx += m1fx + m2fx - cfx;
        fy += m1fy + m2fy - cfy + config.GRAVITY * mass;
        
        
        if (X < 0) {
            x = 0;
            fx -= mass * xv * (2.0 - config.FRICTION);
        }
        else if (X > 800) {
            x = 800;
            fx -= mass * xv * (2.0 - config.FRICTION);
        }
        if (Y < 0) {
            y = 0;
            fy -= mass * yv * (2.0 - config.FRICTION);
        }
        else if (Y > 600) {
            y = 600;
            fy -= mass * yv * (2.0 - config.FRICTION);
        }

        xv += fx / mass - xv * config.FRICTION;
        yv += fy / mass - yv * config.FRICTION;
        
        x += xv;
        y += yv;
    }
    
    public void updateExternal() {
        synchronized (drawLock) {
            X = x;
            Y = y;
            R = r;
        }
    }
    
    public void draw(Graphics2D g) {
        double drawX;
        double drawY;
        double drawR;
        
        synchronized (drawLock) {
            drawX = X;
            drawY = Y;
            drawR = R;
        }
       
        g.setColor(Color.white);
        int intDrawX = (int)(drawX - drawR);
        int intDrawY = (int)(drawY - drawR);
        int intDrawD = (int)(drawR * 2.0);
        g.drawOval(intDrawX, intDrawY, intDrawD, intDrawD);
        
    }
}
