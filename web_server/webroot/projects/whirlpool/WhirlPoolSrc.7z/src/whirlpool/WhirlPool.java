
package whirlpool;

import java.awt.event.ActionEvent;
import javax.swing.Timer;
import whirlpool.cell.Cell;
import whirlpool.render.Window;


/**
 *
 * @author robin
 */
public class WhirlPool {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Config config = new Config();
        Window window = new Window();
        Cell[] cells = new Cell[4 * 4];
        for (int i = 0; i < cells.length/4; i++) {
            Cell cell = new Cell(config, (i+1) * 800 / (cells.length/4 + 1), 100);
            cells[i] = cell;
            window.addObject(cell);
        }
        for (int i = 0; i < cells.length/4; i++) {
            Cell cell = new Cell(config, (i+1) * 800 / (cells.length/4 + 1), 200);
            cells[i + cells.length/4] = cell;
            window.addObject(cell);
        }
        for (int i = 0; i < cells.length/4; i++) {
            Cell cell = new Cell(config, (i+1) * 800 / (cells.length/4 + 1), 300);
            cells[i + 2*cells.length/4] = cell;
            window.addObject(cell);
        }
        for (int i = 0; i < cells.length/4; i++) {
            Cell cell = new Cell(config, (i+1) * 800 / (cells.length/4 + 1), 400);
            cells[i + 3*cells.length/4] = cell;
            window.addObject(cell);
        }
        
        Timer drawingTimer = new Timer(20, (ActionEvent ae) -> {
            window.repaint();
        });
        drawingTimer.start();
        
        Timer physicsTimer = new Timer(20, (ActionEvent ae) -> {
            for (Cell cell : cells) {
                cell.updateInternal(cells);
            }
            for (Cell cell : cells) {
                cell.updateExternal();
            }
        });
        physicsTimer.start();
    }
    
}
